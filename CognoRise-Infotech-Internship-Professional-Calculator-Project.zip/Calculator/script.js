document.addEventListener('DOMContentLoaded', () => {
    // Initialization for Calculator
    const screen = document.getElementById('calculator-screen');
    let currentInput = '';
    let currentHistory = [];

    // Click Sound
    const clickSound = document.getElementById('click-sound');
    const playSound = () => {
        clickSound.currentTime = 0;
        clickSound.play();
    };

    // Number & Operation Buttons
    document.querySelectorAll('.btn').forEach(button => {
        button.addEventListener('click', () => {
            playSound();
            const action = button.dataset.action;
            const value = button.innerText;

            if (action === 'number') {
                handleNumber(value);
            } else if (action === 'operation') {
                handleOperation(value);
            } else if (action === 'dot') {
                handleDot();
            } else if (action === 'clear') {
                handleClear();
            } else if (action === 'delete') {
                handleDelete();
            } else if (action === 'calculate') {
                handleCalculate();
            }
        });
    });

    function handleNumber(value) {
        if (currentInput === '0') {
            currentInput = value;
        } else {
            currentInput += value;
        }
        updateScreen(currentInput);
    }

    function handleOperation(value) {
        if (currentInput !== '') {
            currentInput += ` ${value} `;
            updateScreen(currentInput);
        }
    }

    function handleDot() {
        if (!currentInput.includes('.')) {
            currentInput += '.';
            updateScreen(currentInput);
        }
    }

    function handleClear() {
        currentInput = '';
        updateScreen('0');
    }

    function handleDelete() {
        currentInput = currentInput.slice(0, -1);
        updateScreen(currentInput || '0');
    }

    function handleCalculate() {
        try {
            const result = eval(currentInput.replace(/×/g, '*').replace(/÷/g, '/'));
            currentHistory.push(`${currentInput} = ${result}`);
            updateScreen(result);
            updateHistory();
            currentInput = result.toString();
        } catch (error) {
            updateScreen('Error');
            currentInput = '';
        }
    }

    function updateScreen(value) {
        screen.innerText = value;
    }

    function updateHistory() {
        const historyList = document.getElementById('history-list');
        historyList.innerHTML = currentHistory.map((entry, index) => `
            <li>
                ${entry}
                <button onclick="deleteHistory(${index})">Delete</button>
            </li>
        `).join('');
    }

    // Dark Mode Toggle
    const darkModeToggle = document.getElementById('dark-mode-toggle');
    darkModeToggle.addEventListener('change', () => {
        document.body.classList.toggle('dark-mode');
        document.querySelector('.calculator-container').classList.toggle('dark-mode');
        document.querySelector('.hero-section').classList.toggle('dark-mode');
    });

    // Delete History
    window.deleteHistory = function (index) {
        currentHistory.splice(index, 1);
        updateHistory();
    };

    // Solve Equation Section
    const equationInput = document.getElementById('equation-input');
    const processEquationButton = document.getElementById('process-equation');
    const resultDisplay = document.getElementById('result-display');

    processEquationButton.addEventListener('click', () => {
        const equation = equationInput.value.trim();
        if (equation) {
            try {
                const result = solveEquation(equation);
                resultDisplay.textContent = `Result: ${result}`;
            } catch (error) {
                console.error('Error solving equation:', error);
                resultDisplay.textContent = 'Error solving equation';
            }
        } else {
            resultDisplay.textContent = 'Please enter a valid equation.';
        }
    });

    function solveEquation(equation) {
        // Normalize the equation format
        equation = equation.replace(/−/g, '-').replace(/\s+/g, '');

        // Linear Equation: ax + b = 0
        let matches = equation.match(/^([+-]?\d*\.?\d*)x([+-]?\d*\.?\d*)=0$/);
        if (matches) {
            const a = parseFloat(matches[1] || 1);
            const b = parseFloat(matches[2] || 0);
            if (a === 0) {
                return b === 0 ? 'Infinite solutions' : 'No solution';
            }
            const root = -b / a;
            return `Root: x = ${root}`;
        }

        // Quadratic Equation: ax^2 + bx + c = 0
        matches = equation.match(/^([+-]?\d*\.?\d*)x\^2([+-]?\d*\.?\d*)x([+-]?\d*\.?\d*)=0$/);
        if (matches) {
            const a = parseFloat(matches[1] || 1);
            const b = parseFloat(matches[2] || 0);
            const c = parseFloat(matches[3] || 0);

            // Calculate discriminant
            const discriminant = b * b - 4 * a * c;

            // Calculate roots
            if (discriminant > 0) {
                const root1 = (-b + Math.sqrt(discriminant)) / (2 * a);
                const root2 = (-b - Math.sqrt(discriminant)) / (2 * a);
                return `Roots: x1 = ${root1}, x2 = ${root2}`;
            } else if (discriminant === 0) {
                const root = -b / (2 * a);
                return `Root: x = ${root}`;
            } else {
                return 'No real roots';
            }
        }

        // Cubic Equation: ax^3 + bx^2 + cx + d = 0
        matches = equation.match(/^([+-]?\d*\.?\d*)x\^3([+-]?\d*\.?\d*)x\^2([+-]?\d*\.?\d*)x([+-]?\d*\.?\d*)=0$/);
        if (matches) {
            const a = parseFloat(matches[1] || 1);
            const b = parseFloat(matches[2] || 0);
            const c = parseFloat(matches[3] || 0);
            const d = parseFloat(matches[4] || 0);

            // Solve cubic equations using Cardano's method or other algorithms
            return 'Cubic equations are complex and require advanced methods for solutions. Consider using specialized tools.';
        }

        // Invalid Equation
        throw new Error('Invalid equation format or unsupported equation type');
    }

    // Calculation Sharing
    const shareButton = document.getElementById('share-button');

    shareButton.addEventListener('click', () => {
        const currentCalculation = screen.innerText;
        if (navigator.share) {
            navigator.share({
                title: 'My Calculation',
                text: `Check out this calculation: ${currentCalculation}`,
                url: window.location.href
            }).then(() => {
                console.log('Successfully shared');
            }).catch((error) => {
                console.error('Error sharing', error);
            });
        } else {
            alert('Web Share API is not supported in this browser.');
        }
    });
});
